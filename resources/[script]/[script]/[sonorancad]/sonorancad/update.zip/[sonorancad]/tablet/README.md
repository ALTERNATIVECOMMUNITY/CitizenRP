# tablet
View your CAD in-game with our tablet resource!

## Installation

[Click to view the installation guide.](https://info.sonorancad.com/integration-plugins/integration-plugins/available-plugins/tablet)
