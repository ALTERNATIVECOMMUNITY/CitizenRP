fx_version 'bodacious'

games {'gta5'}

ui_page 'html/index.html'

server_scripts {
    'sv_main.lua'
}

client_scripts {
    'cl_main.lua'
}


files {
    'html/index.html',
    'html/style.css',
    'html/reset.css',
    'html/config.js',
    "html/script.js"
}