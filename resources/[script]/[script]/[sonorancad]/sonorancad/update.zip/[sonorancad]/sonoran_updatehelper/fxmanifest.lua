fx_version 'bodacious'
games {'gta5'}
server_only 'yes'
server_script 's.lua'